import pandas as pd
import numpy as np
from datetime import timedelta
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import IsolationForest, RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.pipeline import Pipeline
import warnings
warnings.filterwarnings("ignore")


# ─── 1. Temperature Trend Prediction ──────────────────────────────────────────
def predict_temperature_trend(df: pd.DataFrame, forecast_days: int = 5) -> pd.DataFrame:
    """Polynomial regression to predict future temperatures with confidence bands."""
    X = np.arange(len(df)).reshape(-1, 1)
    y = df["temperature"].values

    pipe = Pipeline([
        ("poly", PolynomialFeatures(degree=3)),
        ("reg",  Ridge(alpha=1.0))
    ])
    pipe.fit(X, y)

    future_X   = np.arange(len(df), len(df) + forecast_days).reshape(-1, 1)
    pred_temps = pipe.predict(future_X)
    residuals  = y - pipe.predict(X)
    std        = residuals.std()

    future_dates = [df["date"].iloc[-1] + timedelta(days=i + 1) for i in range(forecast_days)]
    return pd.DataFrame({
        "date":           future_dates,
        "predicted_temp": np.round(pred_temps, 2),
        "upper":          np.round(pred_temps + 1.96 * std, 2),
        "lower":          np.round(pred_temps - 1.96 * std, 2),
    })


# ─── 2. Rainfall Forecasting ──────────────────────────────────────────────────
def forecast_rainfall(df: pd.DataFrame, forecast_days: int = 5) -> pd.DataFrame:
    """Gradient Boosted regressor for rainfall forecasting."""
    X = np.column_stack([
        np.arange(len(df)),
        df["temperature"].values,
        df["humidity"].values,
    ])
    y = df["rainfall"].values

    model = GradientBoostingRegressor(n_estimators=100, max_depth=3, random_state=42)
    model.fit(X, y)

    last_temp = df["temperature"].values[-forecast_days:]
    last_hum  = df["humidity"].values[-forecast_days:]
    future_X  = np.column_stack([
        np.arange(len(df), len(df) + forecast_days),
        np.resize(last_temp, forecast_days),
        np.resize(last_hum, forecast_days),
    ])
    rainfall_pred = np.clip(model.predict(future_X), 0, None)

    future_dates = [df["date"].iloc[-1] + timedelta(days=i + 1) for i in range(forecast_days)]
    return pd.DataFrame({
        "date":      future_dates,
        "rainfall":  np.round(rainfall_pred, 2),
        "rain_prob": np.round(np.clip(rainfall_pred / rainfall_pred.max() * 100, 5, 99), 1),
    })


# ─── 3. Anomaly Detection ─────────────────────────────────────────────────────
def detect_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    """Isolation Forest for multivariate anomaly detection."""
    features = df[["temperature", "humidity", "rainfall", "wind_speed"]].values
    scaler   = StandardScaler()
    X_scaled = scaler.fit_transform(features)

    iso = IsolationForest(contamination=0.08, random_state=42)
    labels = iso.fit_predict(X_scaled)

    result = df.copy()
    result["anomaly"] = labels          # -1 = anomaly, 1 = normal
    result["anomaly_score"] = iso.decision_function(X_scaled)
    return result


# ─── 4. Seasonal Pattern Analysis ─────────────────────────────────────────────
def analyze_seasonal_patterns(df: pd.DataFrame) -> dict:
    """Aggregate patterns by month and day-of-week."""
    d = df.copy()
    d["month"]       = d["date"].dt.month
    d["day_of_week"] = d["date"].dt.day_name()

    monthly = (
        d.groupby("month")[["temperature", "humidity", "rainfall"]]
        .mean()
        .reset_index()
        .round(2)
    )
    monthly["month"] = monthly["month"].apply(
        lambda m: ["Jan","Feb","Mar","Apr","May","Jun",
                   "Jul","Aug","Sep","Oct","Nov","Dec"][m - 1]
    )

    dow_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    daily = (
        d.groupby("day_of_week")[["temperature", "humidity"]]
        .mean()
        .reindex([x for x in dow_order if x in d["day_of_week"].unique()])
        .reset_index()
        .round(2)
    )

    return {"monthly": monthly, "daily": daily}


# ─── 5. Future Weather Prediction ─────────────────────────────────────────────
def predict_future_weather(df: pd.DataFrame, forecast_days: int = 5) -> pd.DataFrame:
    """Random Forest multi-output prediction for temp, humidity, wind."""
    n = len(df)
    X = np.arange(n).reshape(-1, 1)

    models    = {}
    targets   = ["temperature", "humidity", "wind_speed"]
    for col in targets:
        m = RandomForestRegressor(n_estimators=100, random_state=42)
        m.fit(X, df[col].values)
        models[col] = m

    future_X     = np.arange(n, n + forecast_days).reshape(-1, 1)
    future_dates = [df["date"].iloc[-1] + timedelta(days=i + 1) for i in range(forecast_days)]

    temp_pred = models["temperature"].predict(future_X)
    hum_pred  = np.clip(models["humidity"].predict(future_X), 0, 100)
    wind_pred = np.clip(models["wind_speed"].predict(future_X), 0, None)

    conditions = []
    for t, h, r in zip(temp_pred, hum_pred, [0] * forecast_days):
        if h > 80:
            conditions.append("🌧️ Rainy")
        elif t > 30:
            conditions.append("☀️ Hot & Sunny")
        elif t < 10:
            conditions.append("❄️ Cold")
        elif h > 60:
            conditions.append("⛅ Cloudy")
        else:
            conditions.append("🌤️ Partly Sunny")

    return pd.DataFrame({
        "date":        future_dates,
        "temperature": np.round(temp_pred, 1),
        "humidity":    np.round(hum_pred, 1),
        "wind_speed":  np.round(wind_pred, 1),
        "condition":   conditions,
    })

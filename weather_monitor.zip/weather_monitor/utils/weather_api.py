import requests

BASE_URL = "https://api.openweathermap.org/data/2.5"

def fetch_weather_data(city: str, api_key: str) -> dict:
    """Fetch current weather for a city."""
    url = f"{BASE_URL}/weather"
    params = {"q": city, "appid": api_key}
    resp = requests.get(url, params=params, timeout=10)
    resp.raise_for_status()
    return resp.json()

def fetch_forecast_data(city: str, api_key: str) -> dict:
    """Fetch 5-day / 3-hour forecast."""
    url = f"{BASE_URL}/forecast"
    params = {"q": city, "appid": api_key}
    resp = requests.get(url, params=params, timeout=10)
    resp.raise_for_status()
    return resp.json()

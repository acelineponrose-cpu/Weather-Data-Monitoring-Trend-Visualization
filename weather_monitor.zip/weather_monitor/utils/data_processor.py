import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def process_weather_data(weather_raw: dict) -> dict:
    """Extract key fields from raw OpenWeatherMap response."""
    return {
        "city":        weather_raw.get("name"),
        "temp_c":      weather_raw["main"]["temp"] - 273.15,
        "feels_like":  weather_raw["main"]["feels_like"] - 273.15,
        "humidity":    weather_raw["main"]["humidity"],
        "pressure":    weather_raw["main"]["pressure"],
        "wind_speed":  weather_raw["wind"]["speed"],
        "description": weather_raw["weather"][0]["description"],
        "visibility":  weather_raw.get("visibility", "N/A"),
    }


def generate_mock_history(base_temp: float, days: int = 30) -> pd.DataFrame:
    """Generate synthetic historical weather data for ML demonstrations."""
    np.random.seed(42)
    dates = [datetime.now() - timedelta(days=i) for i in range(days, 0, -1)]

    # Seasonal sine wave + noise
    t = np.linspace(0, 2 * np.pi, days)
    seasonal    = 5 * np.sin(t)
    trend       = np.linspace(-2, 2, days)
    noise       = np.random.normal(0, 1.5, days)
    temperature = base_temp + seasonal + trend + noise

    # Inject a few anomalies
    anomaly_idx = np.random.choice(days, size=3, replace=False)
    for idx in anomaly_idx:
        temperature[idx] += np.random.choice([-8, 8])

    humidity = np.clip(60 + 20 * np.sin(t + 1) + np.random.normal(0, 5, days), 20, 100)
    rainfall = np.clip(np.random.exponential(2, days), 0, 30)
    wind     = np.clip(5 + 3 * np.sin(t + 0.5) + np.random.normal(0, 1, days), 0, 20)

    return pd.DataFrame({
        "date":        dates,
        "temperature": np.round(temperature, 2),
        "humidity":    np.round(humidity, 1),
        "rainfall":    np.round(rainfall, 2),
        "wind_speed":  np.round(wind, 2),
    })

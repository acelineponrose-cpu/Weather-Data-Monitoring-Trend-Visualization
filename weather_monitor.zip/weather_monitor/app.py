import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import os
from utils.weather_api import fetch_weather_data, fetch_forecast_data
from utils.data_processor import process_weather_data, generate_mock_history
from models.ml_models import (
    predict_temperature_trend,
    forecast_rainfall,
    detect_anomalies,
    analyze_seasonal_patterns,
    predict_future_weather
)
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

# ─── Chart Layout Helper ────────────────────────────────────────────────────────
def chart_layout(yaxis_title):
    return dict(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(15,15,30,0.5)",
        font=dict(color="#E0E0FF", family="Rajdhani"),
        yaxis=dict(title=yaxis_title, gridcolor="rgba(255,255,255,0.07)"),
        xaxis=dict(gridcolor="rgba(255,255,255,0.07)"),
        legend=dict(bgcolor="rgba(0,0,0,0.3)", bordercolor="rgba(255,255,255,0.1)", borderwidth=1),
        margin=dict(t=30, b=30, l=50, r=20),
        height=380
    )

# ─── Page Configuration ────────────────────────────────────────────────────────
st.set_page_config(
    page_title="WeatherSense AI",
    page_icon="🌦️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Load CSS ──────────────────────────────────────────────────────────────────
with open("static/css/style.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# ─── Header ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero-header">
    <div class="hero-inner">
        <span class="hero-icon">🌦️</span>
        <h1 class="hero-title">WeatherSense <span class="accent">AI</span></h1>
        <p class="hero-sub">Real-time monitoring · ML trend prediction · Anomaly detection</p>
    </div>
    <div class="header-blobs"></div>
</div>
""", unsafe_allow_html=True)

# ─── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div class="sidebar-title">⚙️ Control Panel</div>', unsafe_allow_html=True)

    api_key = st.text_input(
        "OpenWeatherMap API Key",
        type="password",
        placeholder="Enter your API key...",
        help="Get your free key at openweathermap.org"
    )

    city = st.text_input("📍 City", value="London", placeholder="e.g. Mumbai, Tokyo, Paris")

    st.markdown("---")
    st.markdown("### 🔬 ML Features")
    show_temp_trend    = st.checkbox("🌡️ Temperature Trend Prediction", value=True)
    show_rainfall      = st.checkbox("🌧️ Rainfall Forecasting", value=True)
    show_anomaly       = st.checkbox("⚠️ Anomaly Detection", value=True)
    show_seasonal      = st.checkbox("📅 Seasonal Pattern Analysis", value=True)
    show_future        = st.checkbox("🔮 Future Weather Prediction", value=True)

    st.markdown("---")
    forecast_days = st.slider("Forecast Days", 1, 7, 5)
    history_days  = st.slider("Historical Data Days", 7, 90, 30)

    fetch_btn = st.button("🚀 Fetch & Analyze", use_container_width=True)
    demo_btn  = st.button("🎲 Run Demo Mode", use_container_width=True)

# ─── Session State ─────────────────────────────────────────────────────────────
if "weather_data" not in st.session_state:
    st.session_state.weather_data  = None
if "forecast_data" not in st.session_state:
    st.session_state.forecast_data = None
if "history_df" not in st.session_state:
    st.session_state.history_df    = None

# ─── Data Fetch ────────────────────────────────────────────────────────────────
if fetch_btn:
    if not api_key:
        st.sidebar.error("Please enter your API key.")
    elif not city:
        st.sidebar.error("Please enter a city name.")
    else:
        with st.spinner("🌐 Fetching live weather data..."):
            try:
                weather  = fetch_weather_data(city, api_key)
                forecast = fetch_forecast_data(city, api_key)
                history  = generate_mock_history(
                    weather["main"]["temp"] - 273.15,
                    history_days
                )
                st.session_state.weather_data  = weather
                st.session_state.forecast_data = forecast
                st.session_state.history_df    = history
                st.sidebar.success("✅ Data fetched successfully!")
            except Exception as e:
                st.sidebar.error(f"Error: {e}")

if demo_btn:
    with st.spinner("🎲 Generating demo data..."):
        base_temp = np.random.uniform(15, 30)
        history   = generate_mock_history(base_temp, history_days)
        st.session_state.weather_data  = {
            "name": city or "Demo City",
            "main": {
                "temp": base_temp + 273.15,
                "feels_like": (base_temp - 2) + 273.15,
                "humidity": np.random.randint(40, 90),
                "pressure": np.random.randint(1000, 1025)
            },
            "weather": [{"description": "partly cloudy", "icon": "02d"}],
            "wind": {"speed": round(np.random.uniform(1, 10), 1)},
            "visibility": np.random.randint(5000, 10000)
        }
        st.session_state.forecast_data = None
        st.session_state.history_df    = history
        st.sidebar.success("✅ Demo data loaded!")

# ─── Main Dashboard ────────────────────────────────────────────────────────────
if st.session_state.weather_data:
    w   = st.session_state.weather_data
    df  = st.session_state.history_df
    temp_c = w["main"]["temp"] - 273.15

    # ── Current Conditions ──────────────────────────────────────────────────────
    st.markdown('<div class="section-title">📡 Current Conditions</div>', unsafe_allow_html=True)
    cols = st.columns(5)
    metrics = [
        ("🌡️ Temperature", f"{temp_c:.1f}°C", ""),
        ("💧 Humidity",    f"{w['main']['humidity']}%", ""),
        ("🔵 Pressure",    f"{w['main']['pressure']} hPa", ""),
        ("💨 Wind",        f"{w['wind']['speed']} m/s", ""),
        ("👁️ Visibility",  f"{w.get('visibility', 'N/A')} m", ""),
    ]
    for col, (label, val, delta) in zip(cols, metrics):
        with col:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">{label}</div>
                <div class="metric-value">{val}</div>
            </div>""", unsafe_allow_html=True)

    cond = w["weather"][0]["description"].title()
    st.markdown(f"""
    <div class="condition-banner">
        🌍 <strong>{w['name']}</strong> &nbsp;|&nbsp; {cond} &nbsp;|&nbsp;
        Feels like: <strong>{w['main']['feels_like'] - 273.15:.1f}°C</strong>
    </div>""", unsafe_allow_html=True)

    st.markdown("---")

    # ── Temperature Trend ───────────────────────────────────────────────────────
    if show_temp_trend and df is not None:
        st.markdown('<div class="section-title">🌡️ Temperature Trend Prediction</div>', unsafe_allow_html=True)
        pred_df = predict_temperature_trend(df, forecast_days)

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=df["date"], y=df["temperature"],
            name="Historical", line=dict(color="#FF6B6B", width=2),
            fill="tozeroy", fillcolor="rgba(255,107,107,0.1)"
        ))
        fig.add_trace(go.Scatter(
            x=pred_df["date"], y=pred_df["predicted_temp"],
            name="Predicted", line=dict(color="#FFE66D", width=2, dash="dash"),
        ))
        fig.add_trace(go.Scatter(
            x=list(pred_df["date"]) + list(pred_df["date"])[::-1],
            y=list(pred_df["upper"]) + list(pred_df["lower"])[::-1],
            fill="toself", fillcolor="rgba(255,230,109,0.15)",
            line=dict(color="rgba(255,230,109,0)"),
            name="Confidence Band"
        ))
        fig.update_layout(**chart_layout("Temperature (°C)"))
        st.plotly_chart(fig, use_container_width=True)

    # ── Rainfall Forecast ───────────────────────────────────────────────────────
    if show_rainfall and df is not None:
        st.markdown('<div class="section-title">🌧️ Rainfall Forecasting</div>', unsafe_allow_html=True)
        rain_df = forecast_rainfall(df, forecast_days)

        col1, col2 = st.columns(2)
        with col1:
            fig = px.bar(
                rain_df, x="date", y="rainfall",
                color="rainfall",
                color_continuous_scale=["#4ECDC4", "#1A535C"],
                labels={"rainfall": "mm"}
            )
            fig.update_layout(**chart_layout("Rainfall (mm)"))
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            fig2 = px.line(
                rain_df, x="date", y="rain_prob",
                labels={"rain_prob": "Probability (%)"},
                markers=True,
                color_discrete_sequence=["#4ECDC4"]
            )
            fig2.update_layout(**chart_layout("Rain Probability (%)"))
            st.plotly_chart(fig2, use_container_width=True)

    # ── Anomaly Detection ───────────────────────────────────────────────────────
    if show_anomaly and df is not None:
        st.markdown('<div class="section-title">⚠️ Anomaly Detection</div>', unsafe_allow_html=True)
        anomaly_df = detect_anomalies(df)
        anomalies  = anomaly_df[anomaly_df["anomaly"] == -1]

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=anomaly_df["date"], y=anomaly_df["temperature"],
            mode="lines", name="Temperature",
            line=dict(color="#A8DADC", width=1.5)
        ))
        fig.add_trace(go.Scatter(
            x=anomalies["date"], y=anomalies["temperature"],
            mode="markers", name="Anomaly",
            marker=dict(color="#FF6B6B", size=12, symbol="x",
                        line=dict(color="white", width=2))
        ))
        fig.update_layout(**chart_layout("Temperature (°C)"))
        st.plotly_chart(fig, use_container_width=True)

        a_count = len(anomalies)
        color = "#FF6B6B" if a_count > 0 else "#6BCB77"
        st.markdown(f"""
        <div class="anomaly-summary" style="border-left: 4px solid {color};">
            {'⚠️' if a_count else '✅'} <strong>{a_count} anomal{'ies' if a_count != 1 else 'y'} detected</strong>
            {'— Review flagged data points above.' if a_count else '— Data looks normal!'}
        </div>""", unsafe_allow_html=True)

    # ── Seasonal Analysis ───────────────────────────────────────────────────────
    if show_seasonal and df is not None:
        st.markdown('<div class="section-title">📅 Seasonal Pattern Analysis</div>', unsafe_allow_html=True)
        seasonal = analyze_seasonal_patterns(df)

        fig = make_subplots(
            rows=1, cols=2,
            subplot_titles=("Monthly Avg Temperature", "Humidity vs Temperature")
        )
        fig.add_trace(go.Bar(
            x=seasonal["monthly"]["month"],
            y=seasonal["monthly"]["temperature"],
            marker_color=px.colors.sequential.Plasma,
            name="Monthly Avg"
        ), row=1, col=1)
        fig.add_trace(go.Scatter(
            x=df["temperature"], y=df["humidity"],
            mode="markers",
            marker=dict(
                color=df["temperature"],
                colorscale="Plasma",
                size=6, opacity=0.6
            ),
            name="Scatter"
        ), row=1, col=2)
        fig.update_layout(height=400, **chart_layout(""))
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig, use_container_width=True)

    # ── Future Weather ──────────────────────────────────────────────────────────
    if show_future and df is not None:
        st.markdown('<div class="section-title">🔮 Future Weather Prediction</div>', unsafe_allow_html=True)
        future = predict_future_weather(df, forecast_days)

        fig = make_subplots(rows=2, cols=1, shared_xaxes=True,
                            subplot_titles=("Temperature Forecast", "Humidity Forecast"))
        fig.add_trace(go.Scatter(
            x=future["date"], y=future["temperature"],
            line=dict(color="#FF6B6B", width=2),
            fill="tozeroy", fillcolor="rgba(255,107,107,0.1)",
            name="Temp"
        ), row=1, col=1)
        fig.add_trace(go.Scatter(
            x=future["date"], y=future["humidity"],
            line=dict(color="#4ECDC4", width=2),
            fill="tozeroy", fillcolor="rgba(78,205,196,0.1)",
            name="Humidity"
        ), row=2, col=1)
        fig.update_layout(height=500, **chart_layout(""))
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig, use_container_width=True)

        st.markdown('<div class="section-title">📋 Forecast Table</div>', unsafe_allow_html=True)
        display_df = future.copy()
        display_df["date"] = display_df["date"].dt.strftime("%a, %b %d")
        display_df.columns = ["Date", "Temp (°C)", "Humidity (%)", "Wind (m/s)", "Condition"]
        st.dataframe(display_df, use_container_width=True, hide_index=True)

else:
    # ── Welcome Screen ──────────────────────────────────────────────────────────
    st.markdown("""
    <div class="welcome-box">
        <div class="welcome-icon">🌍</div>
        <h2>Welcome to WeatherSense AI</h2>
        <p>Enter your <strong>OpenWeatherMap API key</strong> and a <strong>city name</strong> in the sidebar,
        then click <em>Fetch & Analyze</em> — or try <em>Demo Mode</em> to explore without an API key.</p>
        <div class="feature-grid">
            <div class="feature-item">🌡️<br>Temperature Trend</div>
            <div class="feature-item">🌧️<br>Rainfall Forecast</div>
            <div class="feature-item">⚠️<br>Anomaly Detection</div>
            <div class="feature-item">📅<br>Seasonal Patterns</div>
            <div class="feature-item">🔮<br>Future Prediction</div>
        </div>
    </div>
    """, unsafe_allow_html=True)
